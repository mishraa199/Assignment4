//Write a program to print MySirG 5 times on the screen.
#include <stdio.h>
/*int main ()
{
    int i;
     for(i=0;i<5;i++)
        printf("\nMySirG");
    return 0;
}*/
int main()
{
    int i=0;
    while(i<5)
    {
        printf("mySirG\n");
         i++;
    }

    return 0;
}
