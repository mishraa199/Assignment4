//Write a program to print the first 10 natural numbers.
#include <stdio.h>
int main ()
{
    int num;
    for (num=1;num<=10;num++)
    {
        printf("%d\n",num);
    }
    return 0;
}
