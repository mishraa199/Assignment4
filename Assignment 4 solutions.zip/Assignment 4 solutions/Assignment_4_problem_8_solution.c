//Write a program to print squares of the first 10 natural numbers.
#include <stdio.h>
int main ()
{
    int num;
    for(num=1;num<=10;num++)
    {
        printf("%d\n",num*num);
    }
    return 0;
}
