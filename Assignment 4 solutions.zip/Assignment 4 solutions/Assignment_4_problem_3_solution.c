//Write a program to print the first 10 natural numbers in reverse order.
#include <stdio.h>
int main ()
{
    int num;
    for(num=10;num>=1;num--)
    {
        printf("%d\n",num);
    }
    return 0;
}
