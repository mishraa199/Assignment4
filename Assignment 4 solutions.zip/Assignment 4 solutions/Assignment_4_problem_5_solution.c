//Write a program to print the first 10 odd natural numbers in reverse order.
#include <stdio.h>
int main ()
{
    int num;
    for(num=10;num>=1;num--)
    {
        printf("%d\n",num*2-1);
    }
    return 0;
}
