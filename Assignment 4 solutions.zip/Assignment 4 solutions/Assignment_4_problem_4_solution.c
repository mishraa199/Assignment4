//Write a program to print the first 10 odd natural numbers.
#include <stdio.h>
int main ()
{
    int num;
    for (num=1;num<=10;num++)
    {
        printf("%d\n",2*num-1);
    }
    return 0;
}
